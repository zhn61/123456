﻿#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include <windows.h>

#define PIXEL_WIDTH 40
#define PIXEL_HEIGHT 24
#define PI 3.14159265358979323846

void clearScreen() {
    system("cls");
}

void display(char buffer[PIXEL_HEIGHT][PIXEL_WIDTH]) {
    clearScreen();
    for (int i = 0; i < PIXEL_HEIGHT; i++) {
        for (int j = 0; j < PIXEL_WIDTH; j++) {
            printf("%c", buffer[i][j]);
        }
        printf("\n");
    }
}

void displayIntro(char buffer[PIXEL_HEIGHT][PIXEL_WIDTH]) {
    const char* studentID = "20231361";
    const char* name = "박지현";
    int x = PIXEL_WIDTH / 2 - (strlen(studentID) + strlen(name)) / 2;
    int y = PIXEL_HEIGHT / 2;

    for (int i = 0; i < PIXEL_HEIGHT; i++) {
        for (int j = 0; j < PIXEL_WIDTH; j++) {
            buffer[i][j] = ' ';
        }
    }

    for (int i = 0; i < strlen(studentID); i++) {
        buffer[y][x + i] = studentID[i];
    }

    buffer[y][x + strlen(studentID)] = ' ';
    for (int i = 0; i < strlen(name); i++) {
        buffer[y][x + strlen(studentID) + 1 + i] = name[i];
    }
}

void drawCircle(char buffer[PIXEL_HEIGHT][PIXEL_WIDTH], int centerX, int centerY, int radius, char symbol) {
    for (int i = -radius; i <= radius; i++) {
        for (int j = -radius; j <= radius; j++) {
            if (i * i + j * j <= radius * radius) {
                int x = centerX + j;
                int y = centerY + i;
                if (x >= 0 && x < PIXEL_WIDTH && y >= 0 && y < PIXEL_HEIGHT) {
                    buffer[y][x] = symbol;
                }
            }
        }
    }
}

void applyTransformations(int* x, int* y, double angle, int offsetX, int offsetY) {
    // 회전 행렬
    double rad = angle * PI / 180.0;
    int originalX = *x;
    int originalY = *y;

    *x = (int)(originalX * cos(rad) - originalY * sin(rad) + offsetX);
    *y = (int)(originalX * sin(rad) + originalY * cos(rad) + offsetY);
}

void updateBuffer(char buffer[PIXEL_HEIGHT][PIXEL_WIDTH], int sunX, int sunY, int earthX, int earthY, int moonX, int moonY, int sunSize, int earthSize, int moonSize, double earthRotationAngle, double moonRotationAngle) {
    // 화면 초기화
    for (int i = 0; i < PIXEL_HEIGHT; i++) {
        for (int j = 0; j < PIXEL_WIDTH; j++) {
            buffer[i][j] = ' ';
        }
    }

    // 태양 그리기
    for (int i = 0; i < sunSize; i++) {
        for (int j = -i; j <= i; j++) {
            if (sunY + i < PIXEL_HEIGHT && sunX + j < PIXEL_WIDTH && sunX + j >= 0)
                buffer[sunY + i][sunX + j] = 'S';
        }
    }

    // 지구 그리기
    int earthDrawX = 0, earthDrawY = 0;
    applyTransformations(&earthDrawX, &earthDrawY, earthRotationAngle, earthX, earthY);

    for (int i = -earthSize; i <= earthSize; i++) {
        for (int j = -earthSize; j <= earthSize; j++) {
            int rotatedX = earthDrawX + j;
            int rotatedY = earthDrawY + i;
            if (rotatedY < PIXEL_HEIGHT && rotatedY >= 0 && rotatedX < PIXEL_WIDTH && rotatedX >= 0)
                buffer[rotatedY][rotatedX] = 'E';
        }
    }

    // 달 그리기
    int moonDrawX = 0, moonDrawY = 0;
    applyTransformations(&moonDrawX, &moonDrawY, moonRotationAngle, moonX, moonY);
    drawCircle(buffer, moonDrawX, moonDrawY, moonSize, 'M');
}

int main() {
    char buffer[PIXEL_HEIGHT][PIXEL_WIDTH];
    int earthRadius = 12;
    int moonDistance = 6;  // 달이 지구 중심으로부터 떨어진 거리 증가

    int sunSize = 5;
    int earthSize = 3;
    int moonSize = 2;

    int sunX = 20, sunY = 12;  // 태양 위치
    int earthX = sunX + earthRadius, earthY = sunY;  // 지구는 태양으로부터 12만큼 떨어짐
    int moonX = earthX + moonDistance, moonY = earthY; // 달 초기 위치

    int isPlanetsAligned = 0;
    int isRotationStarted = 0;
    int isProgramRunning = 1;
    int introDisplayed = 0;

    double earthRotationAngle = 0;  // 지구 자전 각도
    double earthOrbitAngle = 0;      // 지구 공전 각도
    double moonOrbitAngle = 0;       // 달 공전 각도
    double moonRotationAngle = 0;    // 달 자전 각도

    while (isProgramRunning) {
        if (!introDisplayed) {
            displayIntro(buffer);
            display(buffer);
            introDisplayed = 1;
        }

        if (_kbhit()) {
            char ch = _getch();
            if (ch == 27) {  // ESC 누르면 종료
                isProgramRunning = 0;
            }
            if (ch == 32) {  // 스페이스바가 눌리면
                if (isPlanetsAligned == 0) {
                    isPlanetsAligned = 1;
                    earthX = sunX + earthRadius;
                    earthY = sunY;
                    moonX = earthX + moonDistance; // 달 위치 초기화
                    moonY = earthY;
                    updateBuffer(buffer, sunX, sunY, earthX, earthY, moonX, moonY, sunSize, earthSize, moonSize, earthRotationAngle, moonRotationAngle);
                    display(buffer);
                }
                else if (isRotationStarted == 0) {
                    isRotationStarted = 1;
                }
            }
        }

        if (isPlanetsAligned == 1) {
            if (isRotationStarted == 1) {
                // 지구 자전 업데이트
                earthRotationAngle += 360.0 / 20.0;  // 2초에 1바퀴
                if (earthRotationAngle >= 360) earthRotationAngle -= 360;

                // 지구 공전 업데이트 (반시계 방향, 2초에 1바퀴)
                earthOrbitAngle -= 180.0 / 2.0;  // 반시계 방향
                if (earthOrbitAngle < 0) earthOrbitAngle += 360;

                // 지구의 위치 업데이트 (태양을 중심으로 공전)
                earthX = sunX + earthRadius * cos(earthOrbitAngle * PI / 180.0);
                earthY = sunY + earthRadius * sin(earthOrbitAngle * PI / 180.0);

                // 달의 위치 업데이트 (지구를 중심으로 공전)
                moonOrbitAngle -= 180.0 / 2.0;  // 달도 반시계 방향으로 공전
                if (moonOrbitAngle < 0) moonOrbitAngle += 360;

                moonX = earthX + moonDistance * cos(moonOrbitAngle * PI / 180.0);
                moonY = earthY + moonDistance * sin(moonOrbitAngle * PI / 180.0);

                // 달 자전 업데이트
                moonRotationAngle += 360.0 / 0.5;  // 1초에 2바퀴 (0.5초마다 360도)
                if (moonRotationAngle >= 360) moonRotationAngle -= 360;

                // 행성들 그리기
                updateBuffer(buffer, sunX, sunY, earthX, earthY, moonX, moonY, sunSize, earthSize, moonSize, earthRotationAngle, moonRotationAngle);
                display(buffer);
            }
        }

        Sleep(100);  // 잠시 대기
    }

    return 0;
}
